<?php
//Global Variables
$users_choice = "";
$users_choice_err = "";
$global_message = $session_id = "";
$code = rand(10,100000);
$user_ip = $_SERVER['REMOTE_ADDR'];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include('includes/connect.php');
    // Fetching values from the form using $_POST
    $users_choice = mysqli_real_escape_string($conn,$_POST["username"]);
    
    //Check empty or not
    if(empty($users_choice)) {
        $users_choice_err = "<div class='error'>Required</div>";
    }
    else {
        $sql = "SELECT * FROM `users` WHERE `username` = '$users_choice' OR `email` = '$users_choice'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $account_status = $row['status'];
                $account_verify = $row['verified'];
                $u_name = $row['username'];
                $e_name = $row['email'];
                $name = $row['first_name'].' '.$row['last_name'];
                
                if($account_status != 1) {
                    $users_choice_err = "<div class='error'>Account is not activated</div>";
                }
                elseif($account_verify != 1) {
                    $users_choice_err = "<div class='error'>Account is not verified</div>";
                }
                else {
                    if($users_choice == $row['username']) {
                        $global_message = '<br><div class="alert-message alert alert-success d-flex align-items-center" role="alert">
                               <svg class="bi flex-shrink-0 me-2" height="20" width="20" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
                               <div>
                                 Verification code has been sent successfully.<br>Please check the inbox/spam folder. 
                               </div>
                             </div>';
                        include('smtp/user_code_mail.php');     
                        //Session Start
                        $session_id = md5(1).rand(10,100);
                        $_SESSION['username'] = $users_choice;
                        $_SESSION['ver_code'] = $code;              
                        $_SESSION['forgot_id'] = $session_id; 
                        //Session Start     
                        echo '<script type="text/javascript">setTimeout(function(){window.location.href = "change_password.php";}, 3000);</script>';         
                    }
                    elseif($users_choice == $row['email']) {
                        $global_message = '<br><div class="alert-message alert alert-success d-flex align-items-center" role="alert">
                               <svg class="bi flex-shrink-0 me-2" height="20" width="20" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
                               <div>
                                 Verification code has been sent successfully.<br>Please check the inbox/spam folder. 
                               </div>
                             </div>';
                        include('smtp/user_code_mail.php');     
                        //Session Start
                        $session_id = md5(1).rand(10,100);
                        $_SESSION['username'] = $users_choice;
                        $_SESSION['ver_code'] = $code;              
                        $_SESSION['forgot_id'] = $session_id; 
                        //Session Start     
                        echo '<script type="text/javascript">setTimeout(function(){window.location.href = "change_password.php";}, 3000);</script>';         
                    }
                    else {
                        $global_message = '<br><div class="alert-message alert alert-danger d-flex align-items-center" role="alert">
                    <svg class="bi flex-shrink-0 me-2" height="20" width="20" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                    <div>
                      Something went wrong.
                    </div>
                  </div>';    
                    }
                }
            }    
        }
        else {
            $global_message = '<br><div class="alert-message alert alert-danger d-flex align-items-center" role="alert">
                    <svg class="bi flex-shrink-0 me-2" height="20" width="20" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                    <div>
                      Username or Email does not exists
                    </div>
                  </div>';
        }
    }
    $conn->close();
    }
?>
