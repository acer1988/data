<?php
//Global Variables
$ver_code = "";
$code_err =  "";
$global_message = "";
$update_date = date("d-m-y");
$update_time = date("H:i");
$user_name = $_SESSION['username'];
$code = $_SESSION['ver_code'];              
$session_id = $_SESSION['verify_id']; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include('includes/connect.php');
    // Fetching values from the form using $_POST
    $ver_code = mysqli_real_escape_string($conn,$_POST["code"]);
    
    //Checking inputs if empty
    if(empty($ver_code)) {
      $code_err ="<div class='error'>Required</div>";
    }
    elseif(!preg_match($numbers, $ver_code)) {
      $code_err = "<div class='error'>Only numbers are allowed</div>";
    }
    else {
      $user_name = $_SESSION['username'];
      $email = $_SESSION['email'];              
      $session_id = $_SESSION['verify_id'];
    
      //Checking from DB
      $sql = "SELECT * FROM `users` WHERE `username` = '$user_name' AND `email` = '$email'";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
          $name = $row['first_name'].' '.$row['last_name'];
          $db_ver_code = $row['code'];
          if ($ver_code == $db_ver_code) { 
          //Update in users table
          $update_sql = "UPDATE `users` SET `status`=1,`update_date`='$update_date',`update_time`='$update_time',`code`='NA',`verified`=1 WHERE `username` = '$user_name' AND `email` = '$email'";
          if ($conn->query($update_sql) === TRUE) { 
            //Sending Email
            include('smtp/user_verify_mail.php'); 
            //Sending Email                 
            $_SESSION = array();
            session_destroy();
            $global_message = '<br><div class="alert-message alert alert-success d-flex align-items-center" role="alert">
            <svg class="bi flex-shrink-0 me-2" height="20" width="20" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
            <div>
              Account is verfied.
            </div>
          </div>';
          echo '<script type="text/javascript">
          setTimeout(function(){
              window.location.href = "login.php";
          }, 3000);
        </script>';
          }
          }
        }
      }
    }
  }
?>
