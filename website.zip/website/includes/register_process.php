<?php
//Global Variables
$first_name = $last_name = $user_name = $email = $newpassword = $conpassword = "";
$first_name_err = $last_name_err = $user_name_err = $email_err = $newpassword_err = $conpassword_err =  "";
$passwordmatch_error = "";
$create_date = date("d-m-y");
$update_date = date("d-m-y");
$create_time = date("H:i");
$update_time = date("H:i");
$created_by = SELF_CREATE;
$code = rand(10,100000);
$global_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //DB Connection
    include('includes/connect.php');
    // Fetching values from the form using $_POST
    $first_name = mysqli_real_escape_string($conn,$_POST["fname"]);
    $last_name = mysqli_real_escape_string($conn,$_POST["lname"]);
    $user_name = mysqli_real_escape_string($conn,$_POST["username"]);
    $email = mysqli_real_escape_string($conn,$_POST["email"]);
    $newpassword = mysqli_real_escape_string($conn,$_POST["newpassword"]);
    $conpassword = mysqli_real_escape_string($conn,$_POST["conpassword"]);
    
    //Checking inputs if empty
    if(empty($first_name)) {
        $first_name_err ="<div class='error'>Required</div>";
    }
    elseif (!preg_match($textonly, $first_name)) {
        $first_name_err ="<div class='error'>Only text is allowed</div>";
        }
    elseif(empty($last_name)) {
        $last_name_err ="<div class='error'>Required</div>";
    }
    elseif (!preg_match($textonly, $last_name)) {
        $last_name_err ="<div class='error'>Only text is allowed</div>";
        }
    elseif(empty($user_name)) {
        $user_name_err ="<div class='error'>Required</div>";
    }
    elseif (!preg_match($alphanumeric, $user_name)) {
        $user_name_err ="<div class='error'>Only text & number are allowed</div>";
        }
    elseif(empty($email)) {
        $email_err ="<div class='error'>Required</div>";
    }
    elseif (!preg_match($emailtext, $email)) {
        $email_err ="<div class='error'>Not an valid email</div>";
        }
    elseif(empty($newpassword)) {
        $newpassword_err ="<div class='error'>Required</div>";
    }
    elseif (!preg_match($password_pattern, $newpassword)) {
        $newpassword_err ="<div class='error'>Minimum 8 characters(Capital,Small,Digit & Special Character)</div>";
        }
    elseif(empty($conpassword)) {
        $conpassword_err ="<div class='error'>Required</div>";
    }
    elseif(!preg_match($password_pattern, $conpassword)) {
        $conpassword_err ="<div class='error'>Minimum 8 characters(Capital,Small,Digit & Special Character)</div>";
        }  
    elseif($user_name == "Admin" || $user_name == "Administrator" || $user_name == "Agent" || $user_name == "User" || $user_name == "Manager") {
        $user_name_err ="<div class='error'>".$user_name.' is not allowed'."</div>";
    } 
    elseif($newpassword != $conpassword) {
        $passwordmatch_error = "<div class='error'>Passwords do not match</div>";
    }
    else {
        //Checking of User Data
        $sql_username = "SELECT `username` FROM `users` WHERE `username` = '$user_name'";
        $sql_email = "SELECT `email` FROM `users` WHERE `email` = '$email'";
        $result_u = $conn->query($sql_username);
        $result_e = $conn->query($sql_email);

        if ($result_u->num_rows > 0) {
        // output data of each row
        while($row = $result_u->fetch_assoc()) {
            if($user_name == $row["username"]) {
                $global_message = '<br><div class="alert-message alert alert-warning d-flex align-items-center" role="alert">
                    <svg class="bi flex-shrink-0 me-2" height="20" width="20" role="img" aria-label="Warning:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                    <div>
                    Username already taken
                    </div>
                    </div>';
            };
        }
        }   
        elseif ($result_e->num_rows > 0) {
            // output data of each row
            while($row = $result_e->fetch_assoc()) {
                if($email == $row["email"]) {
                     $global_message = '<br><div class="alert-message alert alert-warning d-flex align-items-center" role="alert">
                    <svg class="bi flex-shrink-0 me-2" height="20" width="20" role="img" aria-label="Warning:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                    <div>
                    Email already taken
                    </div>
                    </div>';
                };
        } 
        }
        else {
             //Sesson Start session 
             $session_id = md5(1).rand(10,100);
             $_SESSION['username'] = $user_name;
             $_SESSION['email'] = $email;              
             $_SESSION['verify_id'] = $session_id;
            //Password Hashing
            $hashed_password = password_hash($newpassword, PASSWORD_DEFAULT);
             //Insertion of User Data
            $sql_users = "INSERT INTO `users`(`first_name`, `last_name`, `username`, `email`, `password`, `status`, `role`, `create_date`, `update_date`, `create_time`, `update_time`,`code`,`verified`, `created_by`) 
            VALUES ('$first_name','$last_name','$user_name','$email','$hashed_password',0,2,'$create_date','$update_date','$create_time','$update_time','$code',0,'$created_by')";

            if ($conn->query($sql_users) === TRUE) {
                $global_message = '<br><div class="alert-message alert alert-success d-flex align-items-center" role="alert">
                <svg class="bi flex-shrink-0 me-2" height="20" width="20" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
                <div>
                  Registration is successful
                </div>
              </div>';
              //Sending the email
                include('smtp/user_reg_mail.php');
                include('smtp/admin_mail.php');
              //Sending the email
              echo '<script type="text/javascript">
                    setTimeout(function(){
                        window.location.href = "verify.php";
                    }, 3000);
                </script>';
            } else {
            echo "Error: " . $sql_users . "<br>" . $conn->error;
            }
             } 
        }
        $conn->close();
    }
    
?>
