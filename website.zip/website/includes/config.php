<?php 
date_default_timezone_set("Asia/Kolkata");
//Website
define("SELF_CREATE","Self");
define("SITE_NAME","Ticket System");
define("SITE_LOGIN","Login");
define("SITE_REG","Register");
define("SITE_VER","Verify");
define("SITE_ADMIN","Admin Login");
define("SITE_FOR","Forgot");
define("SITE_CHGPASS","Change Password");
define("SITE_ADMIN_DASH","Dashboard");
define("SITE_USER_LIST","Users List");

//Database 
define("DB_HOST","localhost");
define("DB_USER","root");
define("DB_PASS","Acer522@0077");
define("DB_NAME","ticket_system");

//Regex Pattern
$textonly = '/^[A-Za-z]+$/';
$alphanumeric = '/^[a-zA-Z0-9]+$/';
$emailtext = '/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix';
$password_pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*]).{8,}$/';
$numbers = '/^[0-9]+$/';

//Site Images
define("SITE_LOGO_BLACK","../assets/img/black-logo.png");
define("SITE_LOGO_RED","../assets/img/red-logo.png");
define("SITE_LOGO_SVGBLACK","../assets/img/svg-black-logo.png");
define("SITE_LOGO_SVG","../assets/img/svg-logo.png");
define("SITE_LOGO_TRANSBLACK","../assets/img/transparent-black-logo.png");
define("SITE_LOGO_TRANS","../assets/img/transparent-logo.png");
define("SITE_LOGO_BG","../assets/img/bg-1.jpg");
?>