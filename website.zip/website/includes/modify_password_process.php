<?php
$user_newpassword = $user_conpassword = $ver_code = "";
$new_password_err = $con_password_err =  $ver_code_err = "";
$global_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include('includes/connect.php');

    $ver_code = mysqli_real_escape_string($conn,$_POST["code"]);  
    $user_newpassword = mysqli_real_escape_string($conn,$_POST["newpassword"]);  
    $user_conpassword = mysqli_real_escape_string($conn,$_POST["conpassword"]);  

    if(empty($ver_code)) {
        $ver_code_err = "<div class='error'>Required</div>"; 
    }
    elseif(!preg_match($numbers,$ver_code)) {
      $ver_code_err = "<div class='error'>Only numbers are allowed</div>";
    }
    elseif(empty($user_newpassword)) {
      $new_password_err = "<div class='error'>Required</div>"; 
    }
    elseif (!preg_match($password_pattern, $user_newpassword)) {
      $new_password_err ="<div class='error'>Minimum 8 characters(Capital,Small,Digit & Special Character)</div>";
      }
    elseif(empty($user_conpassword)) {
      $con_password_err = "<div class='error'>Required</div>"; 
    }
    elseif (!preg_match($password_pattern, $user_conpassword)) {
      $con_password_err ="<div class='error'>Minimum 8 characters(Capital,Small,Digit & Special Character)</div>";
      }
    elseif($user_newpassword != $user_conpassword) {
      $con_password_err = "<div class='error'>Passwords do not match</div>"; 
    }
    else {
      $update_date = date("d-m-y");
      $update_time = date("H:i");
      $u_username = $_SESSION['username'];
      $e_username = $_SESSION['email'];
      $session_id = md5($_SESSION['forgot_id']);
      $u_code = $_SESSION['password'];
      $hashed_password = password_hash($user_newpassword, PASSWORD_DEFAULT);

      if($ver_code == $u_code) {
      $session_update = "UPDATE `users` SET `password`='$hashed_password',`update_date`='$update_date',`update_time`='$update_time' WHERE `username` = '$u_username' OR `email` = '$e_username'";  
      if ($conn->query($session_update) === TRUE) {
        $_SESSION = array();
        session_destroy();
        $global_message = '<br><div class="alert-message alert alert-success d-flex align-items-center" role="alert">
                <svg class="bi flex-shrink-0 me-2" height="20" width="20" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
                <div>
                  Password is successfully changed
                </div>
              </div>';
              include('smtp/password_change_mail.php');
              echo '<script type="text/javascript">
              setTimeout(function(){
                  window.location.href = "login.php";
              }, 3000);
          </script>';
      }
      else {

      }
      }
    }          
}
?>