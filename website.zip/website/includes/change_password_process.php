<?php
$user_input = $newpassword = $conpassword = "";
$user_input_err = $new_password_err = $con_password_err = "";
$global_message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include('includes/connect.php');
    $user_input = mysqli_real_escape_string($conn,$_POST["username"]);  
    if(empty($user_input)) {
        $user_input_err = "<div class='error'>Required</div>"; 
    }
    else {
        $sql = "SELECT * FROM `users` WHERE `username` = '$user_input' OR `email` = '$user_input'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $acct_status = $row['status'];
                $verify_status = $row['verified'];
                $user_role = $row['role'];

                if($verify_status == 0) {
                    $global_message = '<br><div class="alert-message alert alert-danger d-flex align-items-center" role="alert">
                    <svg class="bi flex-shrink-0 me-2" height="20" width="20" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                    <div>
                      Account is not yet verified.
                    </div>
                  </div>';
                  }
                  elseif($acct_status == 0) {
                    $global_message = '<br><div class="alert-message alert alert-danger d-flex align-items-center" role="alert">
                    <svg class="bi flex-shrink-0 me-2" height="20" width="20" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                    <div>
                      Account is not yet activated.
                    </div>
                  </div>';
                  }
                  elseif ($user_role == 2) {
                    $user_name = $row['username'];
                    $user_email = $row['email'];
                    $name = $row['first_name'].' '.$row['last_name'];
                    $code = rand(10,100000);

                    $_SESSION['forgot_id'] = $row['id'].rand(10,100);
                    $_SESSION['username'] = $row['username'];
                    $_SESSION['email'] = $row['email'];
                    $_SESSION['password'] = $code;
                    $session_id = md5($_SESSION['forgot_id']);

                    $global_message = '<br><div class="alert-message alert alert-success d-flex align-items-center" role="alert">
                               <svg class="bi flex-shrink-0 me-2" height="20" width="20" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
                               <div>
                                 Email has been sent successfully. Please check your inbox/spam folder.
                               </div>
                             </div>';
                    include('smtp/user_code_mail.php');
                    echo '<script type="text/javascript">
                    setTimeout(function(){
                        window.location.href = "change_password.php";
                    }, 3000);
                    </script>';    
                  }
                  else {}
            }
        }

    }  
}
?>