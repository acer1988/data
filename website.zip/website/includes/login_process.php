<?php
//Global Variables
$user_name = $password = "";
$user_name_err = $password_err =  "";
$global_message = $session_id = "";
$user_ip = $_SERVER['REMOTE_ADDR'];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include('includes/connect.php');
    // Fetching values from the form using $_POST
    $user_name = mysqli_real_escape_string($conn,$_POST["username"]);
    $password = mysqli_real_escape_string($conn,$_POST["password"]);
    
    //Checking inputs if empty
    if(empty($user_name)) {
        $user_name_err ="<div class='error'>Required</div>";
    }
    elseif(empty($password)) {
        $password_err ="<div class='error'>Required</div>";
    }
    else {
            //Username Query
            $sql_logins_username = "SELECT * FROM `users` WHERE `username` = '$user_name' OR `email` = '$user_name'";
            $result_logins_username = $conn->query($sql_logins_username);
            //Username check and login
            if ($result_logins_username->num_rows > 0) {
            // output data of each row
            while($row = $result_logins_username->fetch_assoc()) {                
                $verify_pass = password_verify($password, $row['password']);
                if ($verify_pass == 1) {
                  $verify_status = $row['verified'];
                  $acct_status = $row['status'];
                  $user_role = $row['role'];
                  if($verify_status == 0) {
                    $global_message = '<br><div class="alert-message alert alert-danger d-flex align-items-center" role="alert">
                    <svg class="bi flex-shrink-0 me-2" height="20" width="20" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                    <div>
                      Account is not yet verified.
                    </div>
                  </div>';
                  }
                  elseif($acct_status == 0) {
                    $global_message = '<br><div class="alert-message alert alert-danger d-flex align-items-center" role="alert">
                    <svg class="bi flex-shrink-0 me-2" height="20" width="20" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                    <div>
                      Account is not yet activated.
                    </div>
                  </div>';
                  }
                  elseif($user_role == 2) {
                             //Insert login Session ID as logs
                             $user_name = $row['username'];
                             $user_email = $row['email'];
                             $start_date = date("d-m-y");
                             $end_date = date("d-m-y");
                             $start_time = date("H:i");
                             $end_time = date("H:i");
         
                             //Sesson Start session 
                             $_SESSION['user_id'] = $row['id'].rand(10,100);
                             $_SESSION['username'] = $row['username'];
                             $_SESSION['email'] = $row['email'];
                             $_SESSION['password'] = $row['password'];
                             $session_id = md5($_SESSION['user_id']);
         
                             //Insertion of sesson details
                             $insert_login_session = "INSERT INTO `login_sessions`(`username`, `email`, `session_id`, `session_startdate`, `session_starttime`, `session_enddate`, `session_endtime`,`session_ip`,`login_status`) 
                             VALUES ('$user_name','$user_email','$session_id','$start_date','$start_time','NA','NA','$user_ip','Active')";
                             if ($conn->query($insert_login_session) === TRUE) {
                               $global_message = '<br><div class="alert-message alert alert-success d-flex align-items-center" role="alert">
                               <svg class="bi flex-shrink-0 me-2" height="20" width="20" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
                               <div>
                                 Login Successful
                               </div>
                             </div>';
                             echo '<script type="text/javascript">
                                   setTimeout(function(){
                                       window.location.href = "user/";
                                   }, 3000);
                               </script>';
                             }
                  }
                  else {
                    $global_message = '<br><div class="alert-message alert alert-danger d-flex align-items-center" role="alert">
                            <svg class="bi flex-shrink-0 me-2" height="20" width="20" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                            <div>
                              Something went wrong.
                            </div>
                          </div>';
                  } 
                        } 
                        else {
                            $global_message = '<br><div class="alert-message alert alert-danger d-flex align-items-center" role="alert">
                            <svg class="bi flex-shrink-0 me-2" height="20" width="20" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                            <div>
                              Please enter a valid password.
                            </div>
                          </div>';
                          }
                        }
                }
                else {
                    $global_message = '<br><div class="alert-message alert alert-danger d-flex align-items-center" role="alert">
                    <svg class="bi flex-shrink-0 me-2" height="20" width="20" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
                    <div>
                      Username or Email does not exists
                    </div>
                  </div>';
                }  
    }
    $conn->close();
    }
?>
