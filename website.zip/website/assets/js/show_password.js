function myLogin() {
    var x = document.getElementById("password");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  }

  function myRegister() {
    var x = document.getElementById("newpassword");
    var y = document.getElementById("conpassword");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }

    if (y.type === "password") {
      y.type = "text";
    } else {
      y.type = "password";
    }
  }
  function myVerify() {
    var z = document.getElementById("code");
    if (z.type === "password") {
      z.type = "text";
    } else {
      z.type = "password";
    }
  }
  