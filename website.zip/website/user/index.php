<?php  
session_start();
include('../includes/config.php'); 
include('../includes/connect.php'); 
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php"); // Redirect to the dashboard if logged in
    exit();
}

//Data from session 
$session_id = md5($_SESSION['user_id']);
$session_username = $_SESSION['username'];
$session_email = $_SESSION['email'];
$session_password = $_SESSION['password'];

//Check Sesson ID and verify
$select_data = "SELECT * FROM `login_sessions` WHERE `session_id` = '$session_id'";
$results = $conn->query($select_data);
if ($results->num_rows > 0) {
    while($row = $results->fetch_assoc()) {
        $session_login_id = $row['id'];
    }
}       
?>

<a href="../logout.php">LOGOUT</a>
