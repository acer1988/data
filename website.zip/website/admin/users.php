<?php  
session_start();
include('../includes/config.php'); 
include('../includes/connect.php'); 
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../admin_login.php"); // Redirect to the dashboard if logged in
    exit();
}

//Data from session 
$session_id = md5($_SESSION['admin_id']);
$session_username = $_SESSION['username'];  
$session_email = $_SESSION['email'];
$session_password = $_SESSION['password'];

//Check Sesson ID and verify
$select_data = "SELECT * FROM `login_sessions` WHERE `session_id` = '$session_id'";
$results = $conn->query($select_data);
if ($results->num_rows > 0) {
    while($row = $results->fetch_assoc()) { 

        $user_name = $row['username'];  
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="../assets/img/transparent-logo.png">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Source+Serif+Pro:400,600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">    
    <!-- Style -->
    <link rel="stylesheet" href="css/style.css">

    <title><?php echo SITE_USER_LIST ?></title>
  </head>
  <body>
  
    
    <aside class="sidebar">
      <div class="toggle">
        <a href="#" class="burger js-menu-toggle" data-toggle="collapse" data-target="#main-navbar">
              <span></span>
            </a>
      </div>
      <div class="side-inner">

        <div class="logo-wrap">
          <div class="logo">
            <span><?php 
            if (isset($_SESSION['admin_id'])) {
                echo '<img src="images/no-image-user.png" height="40" width="40">';
            }
            else {
                echo '<img src="images/no-image-user.png" height="40" width="40">';    
            }
            ?></span>
          </div>
          <span class="logo-text"><?php echo $user_name; ?></span>
        </div>
          
        <div class="search-form">
          <form action="#">
            <span class="wrap-icon">
              <span class="icon-search2"></span>
            </span>
            <input type="text" class="form-control" placeholder="Search...">
          </form>
        </div>
        <div class="nav-menu">
          <ul>
          <li><a href="index.php" class="d-flex align-items-center"><span class="wrap-icon icon-dashboard mr-3"></span><span class="menu-text">Dashboard</span></a></li>
            <li class="active"><a href="users.php" class="d-flex align-items-center"><span class="wrap-icon icon-users mr-3"></span><span class="menu-text">Users</span></a></li>
            <li><a href="#" class="d-flex align-items-center"><span class="wrap-icon icon-book mr-3"></span><span class="menu-text">Books</span></a></li>
            <li><a href="#" class="d-flex align-items-center"><span class="wrap-icon icon-shopping-cart mr-3"></span><span class="menu-text">Store</span></a></li>
            <li><a href="#" class="d-flex align-items-center"><span class="wrap-icon icon-pie-chart mr-3"></span><span class="menu-text">Analytics</span></a></li>
            <li><a href="#" class="d-flex align-items-center"><span class="wrap-icon icon-cog mr-3"></span><span class="menu-text">Settings</span></a></li>
            <li><a href="../logout.php" class="d-flex align-items-center"><span class="wrap-icon icon-arrow-circle-right mr-3"></span><span class="menu-text">Logout</span></a></li>
          </ul>
        </div>
      </div>
      
    </aside>
    <main>
    <div class="site-section">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-md-9">
              <div>
                <table>
                  <tr>
                    <th>Name</th>  
                    <th>Username</th>
                    <th>Email</th>
                    <th>Account Status</th>
                    <th>Role</th>
                    <th>Date Created</th>
                    <th>Time Created</th>
                    <th>Date Updated</th>
                    <th>Time Updated</th>
                    <th>Created By</th>
                    <th>Action</th>
                  </tr>
                  
            <?php
            $all_users = "SELECT * FROM `users`";
            $result_all_users = $conn->query($all_users); 
            if ($result_all_users->num_rows > 0) {
              // output data of each row
              while($row = $result_all_users->fetch_assoc()) {
                echo '<tr><td>'.$row['first_name'].' '.$row['last_name'].'</td>';
                echo '<td>'.$row['username'].'</td>';
                echo '<td>'.$row['email'].'</td>';
                echo '<td>'.$row['status'].'</td>';
                echo '<td>'.$row['role'].'</td>';
                echo '<td>'.$row['create_date'].'</td>';
                echo '<td>'.$row['create_time'].'</td>';
                echo '<td>'.$row['update_time'].'</td>';
                echo '<td>'.$row['update_time'].'</td>';
                echo '<td>'.$row['created_by'].'</td>';
                echo '<td>
                <select class="custom-select" style="width:200px;" id="admin_select" name="admin_action">
                <ul>
                <li><option value="Select an action">Select an action</option></li>
                <li><option value="View">View</option></li>
                <li><option value="Edit">Edit</option></li>
                <li><option value="Delete">Delete</option></li>
                </ul>
                </select>
                </td></tr>';
              }
            }
            ?>
                 </tr>  
              </table>
              </div>
            </div>                
        </div>                
       </div>                
    </div>                
    </main>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
<?php
}
}  
?>
  </body>
</html>

