<?php  
session_start();
include('../includes/config.php'); 
include('../includes/connect.php'); 
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../admin_login.php"); // Redirect to the dashboard if logged in
    exit();
}

//Data from session 
$session_id = md5($_SESSION['admin_id']);
$session_username = $_SESSION['username'];  
$session_email = $_SESSION['email'];
$session_password = $_SESSION['password'];

//Check Sesson ID and verify
$select_data = "SELECT * FROM `login_sessions` WHERE `session_id` = '$session_id'";
$results = $conn->query($select_data);
if ($results->num_rows > 0) {
    while($row = $results->fetch_assoc()) { 

        $user_name = $row['username'];  
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="../assets/img/transparent-logo.png">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Source+Serif+Pro:400,600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">    
    <!-- Style -->
    <link rel="stylesheet" href="css/style.css">

    <title><?php echo SITE_ADMIN_DASH ?></title>
  </head>
  <body>
  
    
    <aside class="sidebar">
      <div class="toggle">
        <a href="#" class="burger js-menu-toggle" data-toggle="collapse" data-target="#main-navbar">
              <span></span>
            </a>
      </div>
      <div class="side-inner">

        <div class="logo-wrap">
          <div class="logo">
            <span><?php 
            if (isset($_SESSION['admin_id'])) {
                echo '<img src="images/no-image-user.png" height="40" width="40">';
            }
            else {
                echo '<img src="images/no-image-user.png" height="40" width="40">';    
            }
            ?></span>
          </div>
          <span class="logo-text"><?php echo $user_name; ?></span>
        </div>
          
        <div class="search-form">
          <form action="#">
            <span class="wrap-icon">
              <span class="icon-search2"></span>
            </span>
            <input type="text" class="form-control" placeholder="Search...">
          </form>
        </div>
        <div class="nav-menu">
          <ul>
            <li class="active"><a href="." class="d-flex align-items-center"><span class="wrap-icon icon-dashboard mr-3"></span><span class="menu-text">Dashboard</span></a></li>
            <li><a href="users.php" class="d-flex align-items-center"><span class="wrap-icon icon-users mr-3"></span><span class="menu-text">Users</span></a></li>
            <li><a href="#" class="d-flex align-items-center"><span class="wrap-icon icon-book mr-3"></span><span class="menu-text">Books</span></a></li>
            <li><a href="#" class="d-flex align-items-center"><span class="wrap-icon icon-shopping-cart mr-3"></span><span class="menu-text">Store</span></a></li>
            <li><a href="#" class="d-flex align-items-center"><span class="wrap-icon icon-pie-chart mr-3"></span><span class="menu-text">Analytics</span></a></li>
            <li><a href="#" class="d-flex align-items-center"><span class="wrap-icon icon-cog mr-3"></span><span class="menu-text">Settings</span></a></li>
            <li><a href="../logout.php" class="d-flex align-items-center"><span class="wrap-icon icon-arrow-circle-right mr-3"></span><span class="menu-text">Logout</span></a></li>
          </ul>
        </div>
      </div>
      
    </aside>
    <main>
      <div class="site-section">
        <div class="container">
          <div class="row justify-content-left">
            <div class="col-md-9">
              <div class="row">
                <div class="col-md-3 card-body text-center">
                    <div>
                    <?php
                        $sql_count = "SELECT * FROM `users`";
                        if ($result_count = mysqli_query($conn, $sql_count)) {
                            $rowcount = mysqli_num_rows( $result_count );
                            echo "<span class='wrap-icon icon-users mr-3' style='font-weight:bold;>'> 
                            <a href='users.php'>
                            Users Count:</span>".$rowcount.
                            '</a>';
                        }
                    ?>
                    </div>  
                </div>
                <div class="col-md-3">
                  <div class="d-flex post-entry">
                   
                  </div>
                </div>    
                </div>
        </div>
      </div>  
      </div>  
      </div>  
    </main>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
<?php
}
}  
?>
  </body>
</html>

