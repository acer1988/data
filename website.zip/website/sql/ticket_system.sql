-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 04, 2024 at 09:55 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ticket_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `login_sessions`
--

CREATE TABLE `login_sessions` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `session_id` varchar(50) DEFAULT NULL,
  `session_startdate` varchar(50) DEFAULT NULL,
  `session_starttime` varchar(50) DEFAULT NULL,
  `session_enddate` varchar(50) DEFAULT NULL,
  `session_endtime` varchar(50) DEFAULT NULL,
  `session_ip` varchar(20) NOT NULL,
  `login_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_sessions`
--

INSERT INTO `login_sessions` (`id`, `username`, `email`, `session_id`, `session_startdate`, `session_starttime`, `session_enddate`, `session_endtime`, `session_ip`, `login_status`) VALUES
(1, 'Sethidanish88', 'sethidanish@gmail.com', 'NA', '31-12-23', '14:29', '31-12-23', '14:29', '::1', 'NA'),
(2, 'Sethidanish88', 'sethidanish@gmail.com', 'NA', '01-01-24', '09:36', '01-01-24', '09:37', '::1', 'NA'),
(3, 'Admin', 'admin@sethi.rf.gd', 'NA', '01-01-24', '09:39', '01-01-24', '09:39', '::1', 'NA'),
(4, 'Sethidanish88', 'sethidanish@gmail.com', 'NA', '01-01-24', '12:34', '01-01-24', '12:34', '::1', 'NA'),
(5, 'Sethidanish88', 'sethidanish@gmail.com', 'NA', '02-01-24', '12:15', '02-01-24', '12:15', '::1', 'NA'),
(6, 'Sethidanish88', 'sethidanish@gmail.com', 'NA', '02-01-24', '12:22', '02-01-24', '12:22', '::1', 'NA'),
(7, 'Sethidanish88', 'sethidanish@gmail.com', 'NA', '02-01-24', '12:29', '02-01-24', '12:58', '::1', 'NA'),
(8, 'Sethidanish88', 'sethidanish@gmail.com', 'NA', '02-01-24', '12:59', '02-01-24', '12:59', '::1', 'NA'),
(9, 'Admin', 'admin@sethi.rf.gd', 'NA', '02-01-24', '13:01', '02-01-24', '13:03', '::1', 'NA'),
(10, 'Admin', 'admin@sethi.rf.gd', 'NA', '02-01-24', '13:04', '02-01-24', '13:04', '::1', 'NA'),
(11, 'Sethidanish88', 'sethidanish@gmail.com', 'NA', '02-01-24', '13:05', '02-01-24', '13:10', '::1', 'NA'),
(12, 'Admin', 'admin@sethi.rf.gd', 'NA', '02-01-24', '13:23', '02-01-24', '13:26', '::1', 'NA'),
(13, 'Admin', 'admin@sethi.rf.gd', 'NA', '02-01-24', '13:40', '02-01-24', '13:42', '::1', 'NA'),
(14, 'Admin', 'sethidanish@outlook.com', 'NA', '04-01-24', '10:48', '04-01-24', '11:50', '::1', 'NA'),
(15, 'Admin', 'sethidanish@outlook.com', 'NA', '04-01-24', '11:50', '04-01-24', '14:24', '::1', 'NA');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `role_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role_name`) VALUES
(1, 'Administrator'),
(4, 'Agent'),
(3, 'Manager'),
(2, 'User');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id` int(11) NOT NULL,
  `status_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id`, `status_name`) VALUES
(1, 'Activated'),
(2, 'Deactivated'),
(3, 'Pending'),
(4, 'Suspended'),
(5, 'Deleted'),
(6, 'Verified'),
(7, 'Unverified');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  `create_date` varchar(50) DEFAULT NULL,
  `update_date` varchar(50) DEFAULT NULL,
  `create_time` varchar(50) DEFAULT NULL,
  `update_time` varchar(50) DEFAULT NULL,
  `code` varchar(20) NOT NULL,
  `verified` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `username`, `email`, `password`, `status`, `role`, `create_date`, `update_date`, `create_time`, `update_time`, `code`, `verified`, `created_by`) VALUES
(2, 'System', 'Admin', 'Admin', 'sethidanish@outlook.com', '$2y$10$roa.OFSP0aNuBU8se1sQDO7Y21bbNt5Xf7QjPM86ERZRvxx4iyB7e', '1', '1', '29-12-23', '29-12-23', '13:46', '13:46', 'NA', '1', 'Self'),
(10, 'Danish', 'Sethi', 'Sethidanish88', 'sethidanish@gmail.com', '$2y$10$roa.OFSP0aNuBU8se1sQDO7Y21bbNt5Xf7QjPM86ERZRvxx4iyB7e', '1', '2', '31-12-23', '04-01-24', '14:28', '10:47', 'NA', '1', 'Self');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login_sessions`
--
ALTER TABLE `login_sessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `role_name` (`role_name`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login_sessions`
--
ALTER TABLE `login_sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
